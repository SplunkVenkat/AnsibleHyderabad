import pytest
from ansible import errors

def test_fake():
    assert True

